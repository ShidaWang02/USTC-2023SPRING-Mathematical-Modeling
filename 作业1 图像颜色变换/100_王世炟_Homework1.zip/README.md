# 数学建模实验一 图像颜色变换

[lab1.ipynb](lab1.ipynb)中包含实验的代码以及结果 

[Requirements.txt](Requirements.txt)中包含实验所用到的库版本以及Python版本

[source/](source/)中包含实验中用到的原图片

[target/](target/)中包含实验中用到的参考图片

生成的图片见[lab1.ipynb](lab1.ipynb)

[Report.pdf](Report.pdf)是本次实验的报告